import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { AppContext } from "../context/AppContext";

const API_BASE = "http://localhost:3000/api/v1";

export default function InstructorDashboard() {
  const { currentUser } = useContext(AppContext);
  const [courses, setCourses] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (currentUser?.id) {
      axios
        .get(`${API_BASE}/courses?instructorId=${currentUser.id}`)
        .then((res) => setCourses(res.data.courses || res.data))
        .catch((err) => console.error("Error fetching instructor courses", err));
    }
  }, [currentUser]);

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">
        Instructor Dashboard
      </h1>

      {/* Create Course button */}
      <button
        onClick={() => navigate("/create-course")}
        className="mb-6 px-5 py-2 bg-indigo-600 text-white rounded-lg shadow hover:bg-indigo-700 transition"
      >
        + Create New Course
      </button>

      {courses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <div
              key={course.id}
              className="bg-white shadow-md rounded-lg p-5 hover:shadow-lg transition"
            >
              <img
                src={course.image}
                alt={course.title}
                className="w-full h-40 object-cover rounded-md mb-3"
              />
              <h2 className="text-xl font-semibold">{course.title}</h2>
              <p className="text-indigo-600 font-bold">{course.price}</p>

              <button
                onClick={() => navigate(`/edit-course/${course.id}`)}
                className="mt-3 px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600"
              >
                Edit Course
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-600 mt-4">
          You haven’t created any courses yet.
        </p>
      )}
    </div>
  );
}

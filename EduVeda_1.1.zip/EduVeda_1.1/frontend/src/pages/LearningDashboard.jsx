// src/pages/LearningDashboard.jsx
import React, { useEffect, useState, useContext } from "react";
import { AppContext } from "../context/AppContext";
import axios from "axios";
import CourseCard from "../components/CourseCard";

const API_BASE = "http://localhost:3000/api/v1";

const LearningDashboard = () => {
  const { currentUser, enrollments } = useContext(AppContext);
  const [enrolledCourses, setEnrolledCourses] = useState([]);

  useEffect(() => {
    if (!currentUser) return;

    // Fetch all courses
    axios
      .get(`${API_BASE}/courses`)
      .then((res) => {
        const allCourses = res.data.courses || res.data;

        // Filter only enrolled courses
        const myCourses = allCourses.filter((course) =>
          enrollments.some(
            (e) =>
              String(e.userId) === String(currentUser.id) &&
              String(e.courseId) === String(course.id)
          )
        );

        setEnrolledCourses(myCourses);
      })
      .catch((err) => console.error("Error fetching courses:", err));
  }, [currentUser, enrollments]);

  if (!currentUser) return <p className="text-center">Loading...</p>;

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">My Learning</h2>
      {enrolledCourses.length === 0 ? (
        <p>You have not enrolled in any courses yet.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {enrolledCourses.map((course) => (
            <CourseCard key={course.id} course={course} isEnrolled={true} />
          ))}
        </div>
      )}
    </div>
  );
};

export default LearningDashboard;

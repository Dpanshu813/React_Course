import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";

// 🔑 Extract YouTube ID
function extractYouTubeId(url) {
  try {
    const regExp =
      /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  } catch {
    return null;
  }
}

const API_BASE = "http://localhost:3000/api/v1";

const EditCourse = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [course, setCourse] = useState(null);

  // lecture inputs for new lecture
  const [lectureTitle, setLectureTitle] = useState("");
  const [lectureDuration, setLectureDuration] = useState("");
  const [lectureLink, setLectureLink] = useState("");

  // fetch course
  useEffect(() => {
    axios
      .get(`${API_BASE}/courses/${id}`)
      .then((res) => setCourse(res.data))
      .catch((err) => console.error("Error fetching course:", err));
  }, [id]);

  if (!course) return <p className="text-center">Loading...</p>;

  // handle field changes
  const handleChange = (e) => {
    setCourse({ ...course, [e.target.name]: e.target.value });
  };

  // add new lecture
  const handleAddLecture = () => {
    const videoId = extractYouTubeId(lectureLink);
    if (!videoId) {
      alert(" Invalid YouTube link");
      return;
    }

    const newLecture = {
      title: lectureTitle,
      duration: lectureDuration,
      youtubeId: videoId,
    };

    setCourse({ ...course, lectures: [...course.lectures, newLecture] });

    setLectureTitle("");
    setLectureDuration("");
    setLectureLink("");
  };

  // delete lecture
  const handleDeleteLecture = (index) => {
    const updatedLectures = course.lectures.filter((_, i) => i !== index);
    setCourse({ ...course, lectures: updatedLectures });
  };

  // save updates
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`${API_BASE}/courses/${id}`, course);
      alert(" Course updated successfully!");
      navigate("/instructor-dashboard");
    } catch (error) {
      console.error("Error updating course:", error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-md rounded-lg mt-6">
      <h2 className="text-2xl font-bold mb-4">Edit Course</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Title */}
        <div>
          <label className="block text-sm font-medium">Course Title</label>
          <input
            type="text"
            name="title"
            value={course.title}
            onChange={handleChange}
            className="mt-1 w-full border rounded-md p-2"
            required
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium">Description</label>
          <textarea
            name="description"
            value={course.description}
            onChange={handleChange}
            className="mt-1 w-full border rounded-md p-2"
            required
          />
        </div>

        {/* Price */}
        <div>
          <label className="block text-sm font-medium">Price ($)</label>
          <input
            type="number"
            name="price"
            value={course.price.replace("$", "")}
            onChange={(e) =>
              setCourse({ ...course, price: `$${e.target.value}` })
            }
            className="mt-1 w-full border rounded-md p-2"
            required
          />
        </div>

        {/* Image */}
        <div>
          <label className="block text-sm font-medium">Course Image URL</label>
          <input
            type="text"
            name="image"
            value={course.image}
            onChange={handleChange}
            className="mt-1 w-full border rounded-md p-2"
            required
          />
        </div>

        {/* Existing Lectures with */}
        <div className="p-4 border rounded-md bg-gray-50">
          <h3 className="text-lg font-semibold mb-2">Lectures</h3>
          <ul className="space-y-2">
            {course.lectures.map((lec, index) => (
              <li
                key={index}
                className="flex justify-between items-center bg-gray-100 p-2 rounded-md"
              >
                <span>
                  {lec.title} ({lec.duration}) →{" "}
                  <span className="font-mono">{lec.youtubeId}</span>
                </span>
                <button
                  type="button"
                  onClick={() => handleDeleteLecture(index)}
                  className="text-red-600 font-bold hover:text-red-800"
                >
                  ❌
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Add New Lecture */}
        <div className="p-4 border rounded-md bg-gray-50">
          <h3 className="text-lg font-semibold mb-2">Add New Lecture</h3>
          <input
            type="text"
            placeholder="Lecture Title"
            value={lectureTitle}
            onChange={(e) => setLectureTitle(e.target.value)}
            className="w-full mb-2 border rounded-md p-2"
          />
          <input
            type="text"
            placeholder="Duration (e.g. 10:30)"
            value={lectureDuration}
            onChange={(e) => setLectureDuration(e.target.value)}
            className="w-full mb-2 border rounded-md p-2"
          />
          <input
            type="text"
            placeholder="YouTube Link"
            value={lectureLink}
            onChange={(e) => setLectureLink(e.target.value)}
            className="w-full mb-2 border rounded-md p-2"
          />
          <button
            type="button"
            onClick={handleAddLecture}
            className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
          >
            ➕ Add Lecture
          </button>
        </div>

        {/* Save */}
        <button
          type="submit"
          className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700"
        >
           Save Changes
        </button>
      </form>
    </div>
  );
};

export default EditCourse;

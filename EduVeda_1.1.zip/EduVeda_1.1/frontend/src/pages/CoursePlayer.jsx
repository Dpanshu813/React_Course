import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import YouTube from "react-youtube";

const API_BASE = "http://localhost:3000/api/v1";

const CoursePlayer = () => {
  const { id } = useParams();
  const [course, setCourse] = useState(null);
  const [currentVideo, setCurrentVideo] = useState(null);

  useEffect(() => {
    axios.get(`${API_BASE}/courses/${id}`).then((res) => {
      setCourse(res.data);
      if (res.data.lectures?.[0]) {
        setCurrentVideo(res.data.lectures[0]);
      }
    });
  }, [id]);

  if (!course) return <p className="text-center mt-5">Loading course...</p>;

  return (
    <div className="p-8 max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Playlist */}
      <div className="md:col-span-1 border rounded-lg p-4 bg-white shadow-sm">
        <h2 className="text-lg font-semibold mb-4">📖 Course Playlist</h2>
        <ul className="space-y-2">
          {course.lectures?.map((lec, idx) => (
            <li
              key={idx}
              className={`p-2 rounded cursor-pointer ${
                currentVideo?.title === lec.title
                  ? "bg-indigo-100 font-medium"
                  : "hover:bg-gray-100"
              }`}
              onClick={() => setCurrentVideo(lec)}
            >
              {lec.title} <span className="text-xs text-gray-500">({lec.duration})</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Video */}
      <div className="md:col-span-2">
        {currentVideo ? (
          <>
            <YouTube videoId={currentVideo.youtubeId} opts={{ width: "100%", height: "400" }} />
            <h2 className="text-2xl font-bold mt-4">{currentVideo.title}</h2>
            <p className="text-gray-600">{course.description}</p>
            <p className="mt-2 text-sm text-gray-500">Instructor: {course.instructor}</p>
          </>
        ) : (
          <p>Select a lecture to play</p>
        )}
      </div>
    </div>
  );
};

export default CoursePlayer;

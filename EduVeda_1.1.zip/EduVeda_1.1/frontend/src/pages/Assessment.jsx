import React, { useEffect, useState } from "react";
import axios from "axios";

const Assessment = () => {
  const [assessments, setAssessments] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3000/assessments")
      .then(res => setAssessments(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Assessments</h2>
      {assessments.length > 0 ? (
        <ul className="list-disc pl-6">
          {assessments.map((a) => (
            <li key={a.id} className="mb-3">
              <strong>{a.title}</strong> ({a.type}) – Max Score: {a.maxScore}
            </li>
          ))}
        </ul>
      ) : (
        <p>No assessments available.</p>
      )}
    </div>
  );
};

export default Assessment;

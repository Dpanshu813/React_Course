// src/pages/EditCourse.jsx
import React from "react";
import { useNavigate, useParams } from "react-router-dom";

const EditCourse = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const handleEditVideos = () => {
    navigate(`/edit-course/${id}/videos`);
  };

  const handleEditAssessments = () => {
    navigate(`/edit-course/${id}/assessments`);
  };

  return (
    <div className="max-w-3xl mx-auto p-8 mt-14 bg-white shadow-xl rounded-2xl text-center">
      <h2 className="text-3xl font-extrabold text-gray-800 mb-4">
        Edit Course
      </h2>
      <p className="mb-8 text-gray-500 text-lg">
        Choose what you want to edit for this course:
      </p>

      <div className="flex flex-col md:flex-row justify-center gap-8">
        {/* Edit Videos Card */}
        <div
          onClick={handleEditVideos}
          className="cursor-pointer flex flex-col items-center justify-center bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-8 py-6 rounded-2xl shadow-md hover:shadow-2xl hover:scale-105 transition duration-300"
        >
          <span className="text-4xl mb-2">🎬</span>
          <span className="font-semibold text-lg">Edit Course Videos</span>
        </div>

        {/* Edit Assessments Card */}
        <div
          onClick={handleEditAssessments}
          className="cursor-pointer flex flex-col items-center justify-center bg-gradient-to-r from-green-500 to-emerald-500 text-white px-8 py-6 rounded-2xl shadow-md hover:shadow-2xl hover:scale-105 transition duration-300"
        >
          <span className="text-4xl mb-2">📝</span>
          <span className="font-semibold text-lg">Edit Assessments</span>
        </div>
      </div>
    </div>
  );
};

export default EditCourse;

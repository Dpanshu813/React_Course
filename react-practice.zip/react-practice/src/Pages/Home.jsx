import React from 'react'

export default function Home() {
  return (
    <div>
      <h1>Welcome to Home Page</h1>
    </div>
  )
}

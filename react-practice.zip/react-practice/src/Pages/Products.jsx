import React from 'react'

export default function Products() {
  return (
    <div>
        <h1>Buy Products</h1>
    </div>
  )
}

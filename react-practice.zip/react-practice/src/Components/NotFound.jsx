import React from 'react'
import { useNavigate } from 'react-router-dom';

export default function NotFound() {

const navigate = useNavigate();

  return (
    <div className='error'>
        <h2>404 | Error Not Found</h2><br />
        <button onClick={() => navigate('/')}>Go to Home Page</button>
    </div>
  )
}

import React from 'react'
import { useLoaderData } from 'react-router-dom';

export default function JobDetails() {

    const jobDetails = useLoaderData()


  return (
    <div>
        <h1>Job Details Page</h1><br />
        <h2><b>Job Title: {jobDetails.title}</b></h2>
        <h3><b>Salary: {jobDetails.salary}</b></h3>
    </div>
  )
}

export const jobDetailsLoader = async ({params}) => {
    const {xyx} = params;
    const res = await fetch("http://localhost:5000/jobs/" + xyx);
    if(!res.ok){
        throw Error("Could not Found Job Details...");
    }
    return res.json();
}
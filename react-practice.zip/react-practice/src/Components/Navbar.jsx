import React from 'react'
import {NavLink, useNavigate} from 'react-router-dom'



export default function Navbar() {

  const navigate = useNavigate();

  return (
    <div className='navbar'>
        <img src = "" alt = "" />
        <ul>
            <NavLink to='/'><li>Home</li></NavLink>
            <NavLink to='/contact'><li>Contact</li></NavLink>
            <NavLink to='/products'><li>Products</li></NavLink>
            <NavLink to='/about'><li>About</li></NavLink>
            <NavLink to='/jobs'><li>Jobs</li></NavLink>
        </ul>
        <button onClick={() => navigate('/about', {replace: true})} style={{color: 'white', backgroundColor: 'black'}}>Get Started</button>
    </div>
  )
}

import React from 'react'

export default function ContactForm() {
  return (
    <>
    <form>
        <input type = "text" placeholder='name'></input>
        <br />
        <input type = 'email' placeholder='Email'></input>
        <br />
        <textarea placeholder='message'></textarea>
        <br />
        <button type='submit' style = {{color:"white", backgroundColor:"black", borderRadius : 6 }}>Submit</button>
    </form>   
    </>
  )
}

import React from 'react'

export default function ContactInfo() {
  return (
    <>
    <div><h4>Email: abc@gmail.com</h4></div>
    <div><h4>Phone: 9876543210</h4></div>
    <div><h4>Address: Ranchi</h4></div>
    </>
  )
}

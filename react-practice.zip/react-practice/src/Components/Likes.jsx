import React, { useState } from 'react'

export default function Likes() {

    const [likes, setLikes] = useState(0);

    const handleClick = () => {
        setLikes(likes + 1 );
    }
  return (
    <button style = {{padding: "5px 10px", borderRadius : "10%", color: "white", backgroundColor: "black"}} onClick={handleClick}>Likes: {likes}</button>
  );
}



import React from 'react'
import { Outlet } from 'react-router-dom'

export default function Instructor() {
  return (
    <div>
        <h1>
            Instr
        </h1>
        <div>
          {<Outlet/>}
        </div>
    </div>
  )
}

import React from 'react'

export default function AddCourse() {
  return (
    <div>
        <h1>Course Added</h1>
    </div>
  )
}

import React from 'react'

export default function MyCourses() {
  return (
    <div>
        <h1>MyCourseeeee</h1>
    </div>
  )
}

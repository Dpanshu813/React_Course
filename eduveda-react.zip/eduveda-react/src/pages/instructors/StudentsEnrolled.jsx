import React from 'react'

export default function StudentsEnrolled() {
  return (
    <div>
        <h1>Studs Enroll</h1>
    </div>
  )
}

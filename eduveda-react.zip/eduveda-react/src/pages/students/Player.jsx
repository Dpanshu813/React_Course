import React from 'react'

export default function Player() {
  return (
    <div>
        <h1>Player...</h1>
    </div>
  )
}

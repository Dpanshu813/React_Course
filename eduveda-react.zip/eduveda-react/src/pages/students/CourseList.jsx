import React from 'react'

export default function CourseList() {
  return (
    <div>
        <h1>Course list demo</h1>
    </div>
  )
}

import React from 'react'

export default function MyEnrollments() {
  return (
    <div>My Enroll</div>
  )
}

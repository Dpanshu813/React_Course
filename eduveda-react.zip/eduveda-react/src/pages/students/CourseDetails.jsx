import React from 'react'

export default function CourseDetails() {
  return (
    <div>
        <h1>Course Detailsss</h1>
    </div>
  )
}

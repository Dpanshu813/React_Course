import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { BrowserRouter } from 'react-router-dom'
import { AppContextProvider } from './context/AppContext.jsx'
import Home from './pages/students/Home.jsx'
import CourseList from './pages/students/CourseList.jsx'
import Loading from './components/students/Loading.jsx'
import Navbar from './components/students/Navbar.jsx'

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <AppContextProvider> 
      <App />
    </AppContextProvider>
  </BrowserRouter>,
)

import React from 'react'

export default function Sidebar() {
  return (
    <div>
        <h1>Sidebar</h1>
    </div>
  )
}

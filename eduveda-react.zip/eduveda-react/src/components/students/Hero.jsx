import React from 'react'

export default function Hero() {
  return (
    <div>
        <h1>Hero</h1>
    </div>
  )
}

import React from 'react'

export default function SearchBar() {
  return (
    <div>
        <h1>Search Barrrrr</h1>
    </div>
  )
}

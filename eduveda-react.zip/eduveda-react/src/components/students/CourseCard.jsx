import React from 'react'

export default function CourseCard() {
  return (
    <div>
        <h1>CourseCard</h1>
    </div>
  )
}

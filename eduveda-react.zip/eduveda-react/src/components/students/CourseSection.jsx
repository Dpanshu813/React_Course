import React from 'react'

export default function CourseSection() {
  return (
    <div>
        <h1>Course Section</h1>
    </div>
  )
}

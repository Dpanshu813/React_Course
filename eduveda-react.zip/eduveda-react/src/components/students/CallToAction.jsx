import React from 'react'

export default function CallToAction() {
  return (
    <div>
        <h1>
            Call To Action
        </h1>
    </div>
  )
}

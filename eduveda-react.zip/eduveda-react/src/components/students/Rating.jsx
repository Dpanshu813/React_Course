import React from 'react'

export default function Rating() {
  return (
    <div>
        <h1>
            Ratingssss
        </h1>
    </div>
  )
}

import React from 'react'

export default function Companies() {
  return (
    <div><h1>Companyyyy</h1></div>
  )
}

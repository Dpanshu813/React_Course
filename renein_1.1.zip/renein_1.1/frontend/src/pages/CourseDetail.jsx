// src/pages/CourseDetail.jsx
import React, { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { AppContext } from "../context/AppContext";

const API_BASE = "http://localhost:3000/api/v1";

const CourseDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser, enrollments, setEnrollments } = useContext(AppContext);

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch course details
  useEffect(() => {
    axios
      .get(`${API_BASE}/courses/${id}`)
      .then((res) => {
        setCourse(res.data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  // Fetch enrollments if not already loaded
  useEffect(() => {
    if (!enrollments || enrollments.length === 0) {
      axios
        .get(`${API_BASE}/enrollments`)
        .then((res) => setEnrollments(res.data))
        .catch(() => {});
    }
  }, [enrollments, setEnrollments]);

  const isEnrolled = enrollments.some(
    (e) => String(e.userId) === String(currentUser?.id) && String(e.courseId) === String(id)
  );

  const handleEnroll = async () => {
    if (!currentUser) {
      alert("Please login to enroll.");
      return;
    }

    if (isEnrolled) {
      navigate(`/course-player/${id}`);
      return;
    }

    try {
      const newEnrollment = { userId: currentUser.id, courseId: id };
      await axios.post(`${API_BASE}/enrollments`, newEnrollment);
      setEnrollments([...enrollments, newEnrollment]);
      alert("🎉 Enrolled successfully!");
      navigate(`/course-player/${id}`);
    } catch (err) {
      console.error("Error enrolling:", err);
    }
  };

  const handleUnenroll = async () => {
    try {
      const enrollment = enrollments.find(
        (e) => String(e.userId) === String(currentUser?.id) && String(e.courseId) === String(id)
      );
      if (!enrollment) return;

      await axios.delete(`${API_BASE}/enrollments/${enrollment.id}`);
      setEnrollments(enrollments.filter((e) => e.id !== enrollment.id));
      alert("✅ Unenrolled successfully!");
    } catch (err) {
      console.error("Error unenrolling:", err);
    }
  };

  if (loading) return <p className="text-center">Loading...</p>;
  if (!course) return <p className="text-center">Course not found</p>;

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Top Section */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h1 className="text-3xl font-bold">{course.title}</h1>
          <p className="mt-2 text-gray-700">{course.description}</p>
          <p className="mt-1 text-sm">
            ⭐ {course.rating} by {course.instructor}
          </p>
        </div>
        <div className="w-72 border p-4 rounded-lg shadow-md">
          <img
            src={course.image}
            alt={course.title}
            className="w-full h-40 object-cover rounded-md mb-3"
          />
          <p className="text-xl font-bold">{course.price}</p>

          {/* Enroll / CoursePlayer / Unenroll Buttons */}
          {isEnrolled ? (
            <>
              <button
                onClick={() => navigate(`/course-player/${id}`)}
                className="w-full mt-3 py-2 rounded-md bg-green-600 hover:bg-green-700 text-white"
              >
                🎬 Go to Course Player
              </button>
              <button
                onClick={handleUnenroll}
                className="w-full mt-2 py-2 rounded-md bg-red-600 hover:bg-red-700 text-white"
              >
                ❌ Unenroll
              </button>
            </>
          ) : (
            <button
              onClick={handleEnroll}
              className="w-full mt-3 py-2 rounded-md bg-blue-600 hover:bg-blue-700 text-white"
            >
              🚀 Enroll Now
            </button>
          )}
        </div>
      </div>

      {/* Course Content */}
      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2">
          <h2 className="text-xl font-semibold mb-3">Course Content</h2>
          <ul className="space-y-2">
            {course.lectures?.map((lec, index) => (
              <li
                key={index}
                className="flex justify-between items-center bg-gray-100 p-2 rounded-md"
              >
                <span>
                  {lec.title} ({lec.duration})
                </span>
              </li>
            ))}
          </ul>
        </div>
        <div />
      </div>
    </div>
  );
};

export default CourseDetail;

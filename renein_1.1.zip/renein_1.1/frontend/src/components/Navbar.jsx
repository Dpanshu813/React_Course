import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AppContext } from "../context/AppContext";

const Navbar = () => {
  const { currentUser, logout } = useContext(AppContext);

  return (
    <nav className="bg-blue-600 p-4 text-white flex justify-between items-center">
      <Link
        to={
          currentUser?.role === "Instructor"
            ? "/instructor-home"
            : currentUser?.role === "Student"
            ? "/student-home"
            : "/"
        }
        className="font-bold text-xl"
      >
        E-Learning
      </Link>

      <div className="flex gap-4 items-center">
        {currentUser?.role === "Student" && (
          <>
            <Link to="/student-home">Home</Link>
            <Link to="/learning-dashboard">My Learning</Link>
          </>
        )}

        {currentUser?.role === "Instructor" && (
          <Link to="/instructor-home">Home</Link>
        )}

        {currentUser ? (
          <>
            <span>Hi, {currentUser.name}</span>

            {currentUser.role === "Instructor" && (
              <Link to="/instructor-dashboard">Instructor Dashboard</Link>
            )}

            <button onClick={logout} className="hover:underline">
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/signup">Signup</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;

// src/components/CourseCard.jsx
import React from "react";
import { useNavigate } from "react-router-dom";

export default function CourseCard({ course, isEnrolled }) {
  const navigate = useNavigate();

  // Ensure course fields match mockserver data structure
  // (id, image, title, instructor, price)

  return (
    <div
      onClick={() => navigate(`/courses/${course.id}`)}
      className="cursor-pointer border rounded-lg shadow-md hover:shadow-lg transition p-4"
    >
      <img
        src={course.image}
        alt={course.title}
        className="w-full h-40 object-cover rounded-md mb-3"
      />
      <h3 className="font-bold text-lg">{course.title}</h3>
      <p className="text-gray-600 text-sm">{course.instructor}</p>
      <p className="text-gray-800 font-semibold mt-1">{course.price}</p>

      {isEnrolled && (
        <p className="mt-2 text-green-600 font-semibold">✅ Enrolled</p>
      )}
    </div>
  );
}

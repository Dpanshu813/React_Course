// responses.js

// Responses for login API
export const loginResponses = {
  success: {
    jwt: "eyJhbGciOiJIUzI1NiJ9.dummy.jwt.token", // <-- replace with real JWT if needed
    message: "Login successful",
  },
  failure: {
    success: false,
    message: "Invalid email or password",
  },
  badRequest: {
    success: false,
    message: "Bad request: missing or invalid fields",
  },
};

// Responses for profile API
export const profileResponses = {
  success: {
    success: true,
    message: "User profile retrieved successfully",
  },
  failure: {
    success: false,
    message: "User not found",
  },
};

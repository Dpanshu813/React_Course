// src/pages/EditCourse.jsx
import React from "react";
import { useNavigate, useParams } from "react-router-dom";

const EditCourse = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const handleEditVideos = () => {
    navigate(`/edit-course/${id}/videos`);
  };

  const handleEditAssessments = () => {
    navigate(`/edit-course/${id}/assessments`);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 mt-10 bg-white shadow-md rounded-lg text-center">
      <h2 className="text-2xl font-bold mb-6">Edit Course</h2>
      <p className="mb-6 text-gray-600">
        Choose what you want to edit for this course:
      </p>
      <div className="flex flex-col md:flex-row justify-center gap-6">
        <div
          onClick={handleEditVideos}
          className="cursor-pointer bg-blue-500 hover:bg-blue-600 text-white px-6 py-4 rounded-lg shadow-md transition"
        >
          🎬 Edit Course Videos
        </div>
        <div
          onClick={handleEditAssessments}
          className="cursor-pointer bg-green-500 hover:bg-green-600 text-white px-6 py-4 rounded-lg shadow-md transition"
        >
          📝 Edit Assessments
        </div>
      </div>
    </div>
  );
};

export default EditCourse;

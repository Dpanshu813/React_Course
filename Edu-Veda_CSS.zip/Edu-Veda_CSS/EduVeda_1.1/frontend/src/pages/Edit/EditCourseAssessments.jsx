// src/pages/EditCourseAssessments.jsx
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const API_BASE = "http://localhost:3000/api/v1";

const EditCourseAssessments = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [assessments, setAssessments] = useState([]);
  const [newAssessmentTitle, setNewAssessmentTitle] = useState("");
  const [newAssessmentDescription, setNewAssessmentDescription] = useState("");
  const [newQuestions, setNewQuestions] = useState([{ text: "", options: ["", "", ""], answer: "" }]);

  useEffect(() => {
    axios.get(`${API_BASE}/assessments?courseId=${id}`)
      .then(res => setAssessments(res.data))
      .catch(err => console.error(err));
  }, [id]);

  if (!assessments) return <p className="text-center mt-5">Loading assessments...</p>;

  // Existing Assessment CRUD
  const handleAssessmentChange = (idx, field, value) => {
    const updated = [...assessments];
    updated[idx][field] = value;
    setAssessments(updated);
  };

  const handleQuestionChange = (assessIdx, qIdx, field, value) => {
    const updated = [...assessments];
    updated[assessIdx].questions[qIdx][field] = value;
    setAssessments(updated);
  };

  const handleOptionChange = (assessIdx, qIdx, optIdx, value) => {
    const updated = [...assessments];
    updated[assessIdx].questions[qIdx].options[optIdx] = value;
    setAssessments(updated);
  };

  const handleAddQuestionToAssessment = (assessIdx) => {
    const updated = [...assessments];
    updated[assessIdx].questions.push({ text: "", options: ["", "", ""], answer: "" });
    setAssessments(updated);
  };

  const handleDeleteQuestionFromAssessment = (assessIdx, qIdx) => {
    const updated = [...assessments];
    updated[assessIdx].questions.splice(qIdx, 1);
    setAssessments(updated);
  };

  const handleDeleteAssessment = async (assessId) => {
    try {
      await axios.delete(`${API_BASE}/assessments/${assessId}`);
      setAssessments(assessments.filter(a => a.id !== assessId));
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddNewAssessment = async () => {
    if (!newAssessmentTitle) return alert("Assessment title required");
    const newAssessment = {
      id: Date.now().toString(),
      courseId: id,
      title: newAssessmentTitle,
      description: newAssessmentDescription,
      questions: newQuestions,
    };
    try {
      await axios.post(`${API_BASE}/assessments`, newAssessment);
      setAssessments([...assessments, newAssessment]);
      setNewAssessmentTitle(""); setNewAssessmentDescription("");
      setNewQuestions([{ text: "", options: ["", "", ""], answer: "" }]);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveAssessments = async () => {
    try {
      await Promise.all(assessments.map(a => axios.put(`${API_BASE}/assessments/${a.id}`, a)));
      alert("Assessments saved successfully!");
      navigate("/instructor-dashboard");
    } catch (err) {
      console.error(err);
    }
  };

  // New Questions handlers
  const handleNewQuestionChange = (qIdx, field, value) => {
    const updated = [...newQuestions];
    updated[qIdx][field] = value;
    setNewQuestions(updated);
  };
  const handleNewOptionChange = (qIdx, optIdx, value) => {
    const updated = [...newQuestions];
    updated[qIdx].options[optIdx] = value;
    setNewQuestions(updated);
  };
  const handleAddNewQuestion = () => {
    setNewQuestions([...newQuestions, { text: "", options: ["", "", ""], answer: "" }]);
  };

  return (
    <div className="max-w-5xl mx-auto p-6 bg-white shadow-md rounded-lg mt-6">
      <h2 className="text-2xl font-bold mb-4">Edit Assessments</h2>

      {/* Existing Assessments */}
      {assessments.map((assess, aIdx) => (
        <div key={assess.id} className="border p-2 rounded mb-2 bg-gray-50">
          <div className="flex justify-between items-center">
            <input value={assess.title} onChange={(e) => handleAssessmentChange(aIdx, "title", e.target.value)} className="border p-1 rounded w-1/2"/>
            <button type="button" onClick={() => handleDeleteAssessment(assess.id)} className="text-red-600">Delete</button>
          </div>
          <textarea value={assess.description} onChange={(e) => handleAssessmentChange(aIdx, "description", e.target.value)} className="border p-1 rounded w-full mt-1"/>
          
          <div className="mt-2">
            {assess.questions.map((q, qIdx) => (
              <div key={qIdx} className="border p-1 rounded mb-1 bg-white">
                <input placeholder="Question" value={q.text} onChange={(e) => handleQuestionChange(aIdx, qIdx, "text", e.target.value)} className="w-full border p-1 rounded mb-1"/>
                {q.options.map((opt, oIdx) => (
                  <input key={oIdx} placeholder={`Option ${oIdx+1}`} value={opt} onChange={(e) => handleOptionChange(aIdx, qIdx, oIdx, e.target.value)} className="w-full border p-1 rounded mb-1"/>
                ))}
                <input placeholder="Answer" value={q.answer} onChange={(e) => handleQuestionChange(aIdx, qIdx, "answer", e.target.value)} className="w-full border p-1 rounded mb-1"/>
                <button type="button" onClick={() => handleDeleteQuestionFromAssessment(aIdx, qIdx)} className="text-red-600 mb-1">Delete Question</button>
              </div>
            ))}
            <button type="button" onClick={() => handleAddQuestionToAssessment(aIdx)} className="bg-green-600 text-white px-2 py-1 rounded mb-2">Add Question</button>
          </div>
        </div>
      ))}

      {/* New Assessment */}
      <div className="border p-4 rounded bg-gray-50">
        <h3 className="font-semibold">New Assessment</h3>
        <input placeholder="Title" value={newAssessmentTitle} onChange={(e) => setNewAssessmentTitle(e.target.value)} className="w-full border p-1 rounded mb-1"/>
        <textarea placeholder="Description" value={newAssessmentDescription} onChange={(e) => setNewAssessmentDescription(e.target.value)} className="w-full border p-1 rounded mb-1"/>
        {newQuestions.map((q, qIdx) => (
          <div key={qIdx} className="border p-1 rounded mb-1 bg-gray-100">
            <input placeholder="Question" value={q.text} onChange={(e) => handleNewQuestionChange(qIdx, "text", e.target.value)} className="w-full border p-1 rounded mb-1"/>
            {q.options.map((opt, oIdx) => (
              <input key={oIdx} placeholder={`Option ${oIdx+1}`} value={opt} onChange={(e) => handleNewOptionChange(qIdx, oIdx, e.target.value)} className="w-full border p-1 rounded mb-1"/>
            ))}
            <input placeholder="Answer" value={q.answer} onChange={(e) => handleNewQuestionChange(qIdx, "answer", e.target.value)} className="w-full border p-1 rounded mb-1"/>
          </div>
        ))}
        <button type="button" onClick={handleAddNewQuestion} className="bg-green-600 text-white px-2 py-1 rounded">Add Question</button>
        <button type="button" onClick={handleAddNewAssessment} className="bg-indigo-600 text-white px-2 py-1 rounded mt-1">Save New Assessment</button>
      </div>

      <button type="button" onClick={handleSaveAssessments} className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 mt-4">Save All Changes</button>
    </div>
  );
};

export default EditCourseAssessments;

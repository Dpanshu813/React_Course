// src/pages/EditCourseVideos.jsx
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

function extractYouTubeId(url) {
  try {
    const regExp =
      /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  } catch {
    return null;
  }
}

const API_BASE = "http://localhost:3000/api/v1";

const EditCourseVideos = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [course, setCourse] = useState(null);
  const [lectureTitle, setLectureTitle] = useState("");
  const [lectureDuration, setLectureDuration] = useState("");
  const [lectureLink, setLectureLink] = useState("");

  useEffect(() => {
    axios.get(`${API_BASE}/courses/${id}`)
      .then(res => setCourse(res.data))
      .catch(err => console.error(err));
  }, [id]);

  if (!course) return <p className="text-center mt-5">Loading course...</p>;

  const handleCourseChange = e => setCourse({ ...course, [e.target.name]: e.target.value });

  const handleAddLecture = () => {
    const videoId = extractYouTubeId(lectureLink);
    if (!videoId) return alert("Invalid YouTube link");

    setCourse({
      ...course,
      lectures: [...course.lectures, { title: lectureTitle, duration: lectureDuration, youtubeId: videoId }],
    });

    setLectureTitle(""); setLectureDuration(""); setLectureLink("");
  };

  const handleDeleteLecture = idx => {
    setCourse({ ...course, lectures: course.lectures.filter((_, i) => i !== idx) });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await axios.put(`${API_BASE}/courses/${id}`, course);
      alert("Course videos updated successfully!");
      navigate("/instructor-dashboard");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-md rounded-lg mt-6">
      <h2 className="text-2xl font-bold mb-4">Edit Course Videos</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input type="text" name="title" value={course.title} onChange={handleCourseChange} className="w-full border p-2 rounded" placeholder="Course Title" required />
        <textarea name="description" value={course.description} onChange={handleCourseChange} className="w-full border p-2 rounded" placeholder="Description" required />
        <input type="text" name="image" value={course.image} onChange={handleCourseChange} className="w-full border p-2 rounded" placeholder="Image URL" required />
        
        <div className="border p-4 rounded bg-gray-50">
          <h3 className="font-semibold">Lectures</h3>
          <ul>
            {course.lectures.map((lec, idx) => (
              <li key={idx} className="flex justify-between p-1 bg-gray-100 rounded mb-1">
                {lec.title} ({lec.duration})
                <button type="button" onClick={() => handleDeleteLecture(idx)} className="text-red-600">❌</button>
              </li>
            ))}
          </ul>

          <input placeholder="Title" value={lectureTitle} onChange={(e) => setLectureTitle(e.target.value)} className="w-full border p-1 rounded my-1"/>
          <input placeholder="Duration" value={lectureDuration} onChange={(e) => setLectureDuration(e.target.value)} className="w-full border p-1 rounded my-1"/>
          <input placeholder="YouTube Link" value={lectureLink} onChange={(e) => setLectureLink(e.target.value)} className="w-full border p-1 rounded my-1"/>
          <button type="button" onClick={handleAddLecture} className="bg-blue-600 text-white px-2 py-1 rounded mt-1">Add Lecture</button>
        </div>

        <button type="submit" className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">Save Videos</button>
      </form>
    </div>
  );
};

export default EditCourseVideos;

// src/pages/LearningDashboard.jsx
import React, { useContext, useEffect, useState } from "react";
import { AppContext } from "../context/AppContext";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const API_BASE = "http://localhost:3000/api/v1";

export default function LearningDashboard() {
  const { currentUser, enrollments } = useContext(AppContext);
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (!currentUser) return;

    axios
      .get(`${API_BASE}/courses`)
      .then((res) => {
        const allCourses = res.data.courses || res.data;
        const myCourses = allCourses.filter((course) =>
          enrollments?.some(
            (e) =>
              String(e.userId) === String(currentUser.id) &&
              String(e.courseId) === String(course.id)
          )
        );
        setEnrolledCourses(myCourses);
      })
      .catch((err) => console.error("Error fetching courses:", err));
  }, [currentUser, enrollments]);

  if (!currentUser) return <p className="text-center mt-10">Loading...</p>;

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">My Learning</h2>

      {enrolledCourses.length === 0 ? (
        <p>You have not enrolled in any courses yet.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {enrolledCourses.map((course) => (
            <div
              key={course.id}
              className="bg-white shadow rounded-lg p-4 hover:shadow-lg transition"
            >
              <img
                src={course.image}
                alt={course.title}
                className="w-full h-40 object-cover rounded mb-3"
              />
              <h3 className="text-lg font-semibold">{course.title}</h3>
              <p className="text-indigo-600 font-bold">{course.price}</p>

              <button
                onClick={() => navigate(`/course-player/${course.id}`)}
                className="mt-3 w-full py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Continue Learning
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

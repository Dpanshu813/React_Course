// src/pages/CourseDetail.jsx
import React, { useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { AppContext } from "../context/AppContext";

const API_BASE = "http://localhost:3000/api/v1";

export default function CourseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser, enrollments, setEnrollments } = useContext(AppContext);

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get(`${API_BASE}/courses/${id}`)
      .then((res) => {
        setCourse(res.data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (!enrollments || enrollments.length === 0) {
      axios
        .get(`${API_BASE}/enrollments`)
        .then((res) => setEnrollments(res.data))
        .catch(() => {});
    }
  }, [enrollments, setEnrollments]);

  const isEnrolled = enrollments?.some(
    (e) => String(e.userId) === String(currentUser?.id) && String(e.courseId) === String(id)
  );

  const handleEnroll = async () => {
    if (!currentUser) {
      alert("Please login to enroll.");
      return;
    }
    if (isEnrolled) {
      navigate(`/course-player/${id}`);
      return;
    }
    try {
      const newEnrollment = { userId: currentUser.id, courseId: id };
      const res = await axios.post(`${API_BASE}/enrollments`, newEnrollment);
      setEnrollments([...enrollments, res.data]);
      alert("Enrolled successfully!");
      navigate(`/course-player/${id}`);
    } catch (err) {
      console.error("Error enrolling:", err);
    }
  };

  const handleUnenroll = async () => {
    try {
      const enrollment = enrollments.find(
        (e) => String(e.userId) === String(currentUser?.id) && String(e.courseId) === String(id)
      );
      if (!enrollment) return;

      await axios.delete(`${API_BASE}/enrollments/${enrollment.id}`);
      setEnrollments(enrollments.filter((e) => e.id !== enrollment.id));
      alert("Unenrolled successfully!");
    } catch (err) {
      console.error("Error unenrolling:", err);
    }
  };

  if (loading) return <p className="text-center mt-10 text-gray-500">Loading...</p>;
  if (!course) return <p className="text-center mt-10 text-red-500">Course not found</p>;

  return (
    <div className="relative w-full">
      {/* Hero Image */}
      <div className="relative w-full h-[80vh] md:h-[90vh]">
        <img
          src={course.image}
          alt={course.title}
          className="w-full h-full object-cover brightness-90"
        />

        {/* Overlay Course Card */}
        <div className="absolute top-1/2 right-6 md:right-16 transform -translate-y-1/2 w-full md:w-1/3 bg-white p-6 rounded-xl shadow-xl flex flex-col justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-3">{course.title}</h1>
            <p className="text-gray-700 mb-2">{course.description}</p>
            <p className="text-sm text-gray-500 mb-4">
              ⭐ {course.rating} by {course.instructor}
            </p>

            {course.lectures?.length > 0 && (
              <div className="overflow-y-auto max-h-[50vh]">
                <h2 className="text-lg md:text-xl font-semibold mb-2">Course Content</h2>
                <ul className="space-y-2">
                  {course.lectures.map((lec) => (
                    <li
                      key={lec.id}
                      className="flex justify-between items-center bg-gray-100 p-2 rounded"
                    >
                      {lec.title} ({lec.duration})
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Buttons */}
          <div className="mt-4">
            {isEnrolled ? (
              <>
                <button
                  onClick={() => navigate(`/course-player/${id}`)}
                  className="w-full mb-2 py-3 bg-green-600 hover:bg-green-700 text-white rounded-2xl font-medium transition"
                >
                  Go to Course Player
                </button>
                <button
                  onClick={handleUnenroll}
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-medium transition"
                >
                  Unenroll
                </button>
              </>
            ) : (
              <button
                onClick={handleEnroll}
                className="w-full py-3 bg-purple-600 hover:bg-pink-600 text-white rounded-2xl font-medium transition"
              >
                Enroll Now
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

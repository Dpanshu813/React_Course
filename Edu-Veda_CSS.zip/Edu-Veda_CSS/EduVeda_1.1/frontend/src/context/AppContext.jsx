import React, { createContext, useState, useEffect, useContext } from "react";
import axios from "axios";

const API_BASE = "http://localhost:3000/api/v1";

// ✅ Create context
const AppContext = createContext();

// ✅ Provider
export const AppProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(
    JSON.parse(localStorage.getItem("currentUser")) || null
  );
  const [enrollments, setEnrollments] = useState([]);

  // Keep user in localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem("currentUser", JSON.stringify(currentUser));
    } else {
      localStorage.removeItem("currentUser");
    }
  }, [currentUser]);

  // Fetch enrollments from mockserver when user logs in
  useEffect(() => {
    if (currentUser) {
      axios
        .get(`${API_BASE}/enrollments?userId=${currentUser.id}`)
        .then((res) => setEnrollments(res.data.enrollments || res.data))
        .catch(() => setEnrollments([]));
    } else {
      setEnrollments([]);
    }
  }, [currentUser]);

  const login = (user) => {
    setCurrentUser(user);
    localStorage.setItem("currentUser", JSON.stringify(user));
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem("currentUser");
    setEnrollments([]);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        login,
        logout,
        enrollments,
        setEnrollments,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

// ✅ Export both AppContext & helper hook
export { AppContext };

export const useAppContext = () => {
  return useContext(AppContext);
};

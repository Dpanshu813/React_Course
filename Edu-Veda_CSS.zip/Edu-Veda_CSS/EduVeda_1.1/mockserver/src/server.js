const jsonServer = require('json-server');
const server = jsonServer.create();
const middlewares = jsonServer.defaults();
const path = require('path');
const fs = require('fs');
const low = require('lowdb');
const FileSync = require('lowdb/adapters/fileSync');

// Define the API prefix
const API_PREFIX = '/api/v1';

// Directory for JSON files
const dataDir = path.join(__dirname, 'data');

// Create a map of resource names to lowdb instances
const dbMap = {};
fs.readdirSync(dataDir).forEach(file => {
  if (file.endsWith('.json')) {
    const resourceName = file.replace('.json', '');
    const adapter = new FileSync(path.join(dataDir, file));
    dbMap[resourceName] = low(adapter);
  }
});

// Create a merged DB for json-server router
const db = {};
Object.keys(dbMap).forEach(resource => {
  db[resource] = dbMap[resource].get(resource).value() || [];
});

// Create router with merged data
const router = jsonServer.router(db, { id: 'id' });

// Custom ID generation
router.db._.id = 'id';
router.db._.createId = function (coll) {
  return String(coll.length + 1);
};

// Apply middlewares
server.use(middlewares);
server.use(jsonServer.bodyParser);

// Import response constants
const { loginResponses, profileResponses } = require('./responses');

// Custom API handlers
const apiHandlers = {
  'auth/login': (req, res) => {
    const { username, password } = req.body;
    console.log("username: ",username)
    console.log("password: ",password)
    if (!username || !password ) {
      return res.status(400).jsonp(loginResponses.badRequest);
    }
    // console.log("dbMap: ",dbMap)
    const users = dbMap.users.get('users').value() || [];
    const user = users.find(u => u.email === username && u.password === password);

    if (user) {
      res.jsonp({ ...user, jwt: loginResponses.success.jwt });
    } else {
      res.status(401).jsonp(loginResponses.failure);
    }
  },

  'profile': (req, res) => {
    const userProfile = db.users[0];
    if (userProfile) {
      res.jsonp({
        ...profileResponses.success,
        profile: { username: userProfile.username, id: userProfile.id }
      });
    } else {
      res.status(404).jsonp(profileResponses.failure);
    }
  },

  'courses/:courseId/videos/:videoId': (req, res) => {
    const { courseId, videoId } = req.params;
    const courses = dbMap.courses.get('courses');
    const course = courses.find({ id: courseId }).value();

    if (!course) return res.status(404).jsonp({ error: "Course not found" });
    if (!course.videos || course.videos.length === 0) {
      return res.status(404).jsonp({ error: "No videos found for this course" });
    }

    const updatedVideos = course.videos.filter(v => String(v.id) !== String(videoId));
    course.videos = updatedVideos;

    courses.find({ id: courseId }).assign(course).write();
    db['courses'] = courses.value();

    res.jsonp({ message: "Video deleted successfully", course });
  }
};

// Register custom routes with API prefix
Object.entries(apiHandlers).forEach(([path, handler]) => {
  const fullPath = `${API_PREFIX}/${path}`;
  if (path === 'auth/login') {
    server.post(fullPath, handler);
  } else if (path.includes('courses/:courseId/videos/:videoId')) {
    server.delete(fullPath, handler);
  } else {
    server.get(fullPath, handler);
  }
  console.log(`Registered handler for: ${fullPath}`);
});

// Custom middleware for POST, PUT, DELETE
server.use((req, res, next) => {
  const resource = req.path.replace(`${API_PREFIX}/`, '').split('/')[0];
  if (!dbMap[resource]) return next();

  if (req.method === 'POST') {
    const data = req.body;
    if (!data.id) {
      data.id = String(dbMap[resource].get(resource).value().length + 1);
    }

    try {
      dbMap[resource].get(resource).push(data).write();
      db[resource] = dbMap[resource].get(resource).value();
      return res.jsonp(data);
    } catch (e) {
      return res.status(500).jsonp({ error: 'Failed to save data' });
    }
  } else if (req.method === 'PUT') {
    const id = req.path.split('/').pop();
    const data = req.body;

    try {
      const resourceData = dbMap[resource].get(resource);
      const items = resourceData.value();
      const index = items.findIndex(item => String(item.id) === String(id));

      if (index === -1) return res.status(404).jsonp({ error: `${resource} not found` });

      items[index] = { ...data, id };
      dbMap[resource].set(resource, items).write();
      db[resource] = items;

      return res.jsonp(items[index]);
    } catch (e) {
      return res.status(500).jsonp({ error: 'Failed to update data' });
    }
  } else if (req.method === 'DELETE') {
    const id = req.path.split('/').pop();

    try {
      const resourceData = dbMap[resource].get(resource);
      const items = resourceData.value();
      const index = items.findIndex(item => String(item.id) === String(id));

      if (index === -1) return res.status(404).jsonp({ error: `${resource} not found` });

      items.splice(index, 1);
      dbMap[resource].set(resource, items).write();
      db[resource] = items;

      return res.status(204).jsonp({});
    } catch (e) {
      return res.status(500).jsonp({ error: 'Failed to delete data' });
    }
  }

  next();
});

// Apply router for other CRUD operations
server.use(API_PREFIX, router);

server.listen(3000, () => {
  console.log('JSON Server is running on port 3000');
});

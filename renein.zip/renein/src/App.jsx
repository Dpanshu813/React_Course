import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import LandingPage from "./pages/LandingPage";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import CourseDetail from "./pages/CourseDetail";
import CoursePlayer from "./pages/CoursePlayer";
import LearningDashboard from "./pages/LearningDashboard";
import InstructorDashboard from "./pages/InstructorDashboard";
import CreateCourse from "./pages/CreateCourse";
import EditCourse from "./pages/EditCourse";
import Enrollment from "./pages/Enrollment";
import Assessment from "./pages/Assessment";
import Notifications from "./pages/Notifications";
import SearchPage from "./pages/SearchPage";
import InstructorHome from "./pages/InstructorHome";

import ProtectedRoute from "./components/ProtectedRoute";
import { AppProvider } from "./context/AppContext";

function App() {
  return (
    <AppProvider>
      <Router>
        <Navbar />
        <Routes>
          {/* Landing Page */}
          <Route path="/" element={<LandingPage />} />

          {/* Auth */}
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />

          {/* Public course routes */}
          <Route path="/courses/:id" element={<CourseDetail />} />
          <Route path="/course-player/:id" element={<CoursePlayer />} />

  
          <Route
            path="/learning-dashboard"
            element={
              <ProtectedRoute role="Student">
                <LearningDashboard />
              </ProtectedRoute>
            }
          />

          {/* Instructor Routes */}
          <Route
            path="/instructor-home"
            element={
              <ProtectedRoute role="Instructor">
                <InstructorHome />
              </ProtectedRoute>
            }
          />
          <Route
            path="/instructor-dashboard"
            element={
              <ProtectedRoute role="Instructor">
                <InstructorDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/create-course"
            element={
              <ProtectedRoute role="Instructor">
                <CreateCourse />
              </ProtectedRoute>
            }
          />
          <Route
            path="/edit-course/:id"
            element={
              <ProtectedRoute role="Instructor">
                <EditCourse />
              </ProtectedRoute>
            }
          />

          {/* Optional pages */}
          <Route path="/enroll" element={<Enrollment />} />
          <Route path="/assessments" element={<Assessment />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/search" element={<SearchPage />} />
          
        </Routes>
      </Router>
    </AppProvider>
  );
}

export default App;

import React, { createContext, useState, useEffect, useContext } from "react";

// ✅ Create context
const AppContext = createContext();

// ✅ Provider
export const AppProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(
    JSON.parse(localStorage.getItem("currentUser")) || null
  );
  const [enrollments, setEnrollments] = useState([]);

  // Keep user in localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem("currentUser", JSON.stringify(currentUser));
    } else {
      localStorage.removeItem("currentUser");
    }
  }, [currentUser]);

  const login = (user) => {
    setCurrentUser(user);
    localStorage.setItem("currentUser", JSON.stringify(user));
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem("currentUser");
    // ❌ removed useNavigate, redirect will be handled in Navbar or Login
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        login,
        logout,
        enrollments,
        setEnrollments,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

// ✅ Export both AppContext & helper hook
export { AppContext };

export const useAppContext = () => {
  return useContext(AppContext);
};

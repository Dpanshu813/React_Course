import React, { useEffect, useState, useContext } from "react";
import axios from "axios";
import { AppContext } from "../context/AppContext";

const Enrollment = () => {
  const { currentUser } = useContext(AppContext);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/courses")
      .then((res) => setCourses(res.data))
      .catch((err) => console.error(err));
  }, []);

  const handleEnroll = async (course) => {
    if (!currentUser) {
      alert("Please login to enroll.");
      return;
    }

    try {
      await axios.patch(`http://localhost:5000/courses/${course.id}`, {
        StudentID: currentUser.id,
      });
      alert(`Enrolled in ${course.title}!`);
    } catch (err) {
      console.error("Error enrolling:", err);
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Enroll in Courses</h2>
      <div className="flex flex-wrap gap-6">
        {courses.map((course) => (
          <div key={course.id} className="border p-4 rounded w-72 bg-white">
            <h3 className="text-lg font-bold">{course.title}</h3>
            <p>Instructor: {course.instructor}</p>
            <p>Lessons: {course.lessons}</p>
            <button
              className="bg-green-500 text-white px-3 py-1 mt-3 rounded hover:bg-green-600"
              onClick={() => handleEnroll(course)}
            >
              Enroll
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Enrollment;

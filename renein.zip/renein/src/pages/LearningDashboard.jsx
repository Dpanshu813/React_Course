import React, { useEffect, useState, useContext } from "react";
import axios from "axios";
import CourseCard from "../components/CourseCard";
import { AppContext } from "../context/AppContext";

export default function LearningDashboard() {
  const { enrollments, currentUser } = useContext(AppContext);
  const [courses, setCourses] = useState([]);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState("all");

  useEffect(() => {
    axios
      .get("http://localhost:5000/courses")
      .then((res) => setCourses(res.data))
      .catch((err) => console.error("Error fetching courses:", err));
  }, []);

  const filteredCourses = courses.filter((c) =>
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  const myLearningCourses = courses.filter((c) =>
    enrollments.some((e) => e.userId === currentUser?.id && e.courseId === c.id)
  );

  const displayedCourses = tab === "all" ? filteredCourses : myLearningCourses;

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex gap-4 mb-6">
        <button
          className={`px-4 py-2 rounded-md ${
            tab === "all" ? "bg-indigo-600 text-white" : "bg-gray-200"
          }`}
          onClick={() => setTab("all")}
        >
          All Courses
        </button>
        <button
          className={`px-4 py-2 rounded-md ${
            tab === "mylearning" ? "bg-indigo-600 text-white" : "bg-gray-200"
          }`}
          onClick={() => setTab("mylearning")}
        >
          My Learning
        </button>
      </div>

      {tab === "all" && (
        <div className="mb-6">
          <input
            type="text"
            placeholder="Search courses..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full border p-2 rounded-md"
          />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {displayedCourses.map((course) => {
          const isEnrolled = enrollments.some(
            (e) => e.userId === currentUser?.id && e.courseId === course.id
          );
          return (
            <CourseCard key={course.id} course={course} isEnrolled={isEnrolled} />
          );
        })}
      </div>
    </div>
  );
}

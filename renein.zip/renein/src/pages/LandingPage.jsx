import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const LandingPage = () => {
  const [featuredCourses, setFeaturedCourses] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/courses?_limit=3") // fetch top 3 featured courses
      .then((res) => setFeaturedCourses(res.data))
      .catch((err) => console.error("Error fetching featured courses:", err));
  }, []);

  return (
    <div className="bg-gradient-to-b from-gray-100 via-white to-gray-200 min-h-screen">
      {/* Hero Section */}
      <section className="relative text-center py-20 bg-gradient-to-r from-blue-100 to-gray-200 shadow-md">
        <h1 className="text-5xl font-extrabold text-gray-800">
          Learn Anytime, Anywhere 🌍
        </h1>
        <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
          Unlock your potential with top-rated courses taught by expert
          instructors. Education made simple, engaging, and accessible for all.
        </p>
        <div className="mt-6 flex justify-center space-x-4">
          <Link
            to="/student-home"
            className="px-6 py-3 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
          >
            Browse Courses
          </Link>
          <Link
            to="/signup"
            className="px-6 py-3 rounded-lg bg-white text-blue-600 border border-blue-600 hover:bg-gray-100 transition"
          >
            Join Now
          </Link>
        </div>
      </section>

      {/* Quote Section */}
      <section className="py-16 bg-white text-center">
        <blockquote className="text-2xl italic text-gray-700 max-w-3xl mx-auto">
          “Education is the most powerful weapon which you can use to change the
          world.”  
        </blockquote>
        <p className="mt-4 font-semibold text-gray-600">— Nelson Mandela</p>
      </section>

      {/* Featured Courses */}
      <section className="py-16 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-10">
          🌟 Featured Courses
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {featuredCourses.map((course) => (
            <div
              key={course.id}
              className="bg-white rounded-lg shadow-md hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 overflow-hidden"
            >
              <img
                src={course.image}
                alt={course.title}
                className="w-full h-40 object-cover"
              />
              <div className="p-5">
                <h3 className="text-xl font-semibold text-gray-800">
                  {course.title}
                </h3>
                <p className="text-gray-600 text-sm mb-3">
                  by {course.instructor}
                </p>
                <p className="font-bold text-blue-600">{course.price}</p>
                <Link
                  to={`/courses/${course.id}`}
                  className="block mt-4 text-center bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
                >
                  Explore Course
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-300 py-8 text-center">
        <p>&copy; {new Date().getFullYear()} E-Learning Platform. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default LandingPage;

// src/pages/CourseDetail.jsx
import React, { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { AppContext } from "../context/AppContext";

const CourseDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser, enrollments, setEnrollments } = useContext(AppContext);

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get(`http://localhost:5000/courses/${id}`)
      .then((res) => {
        setCourse(res.data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  const isEnrolled = enrollments.some(
    (e) => e.userId === currentUser?.id && e.courseId === Number(id)
  );

  const handleEnroll = async () => {
    if (!currentUser) {
      alert("Please login to enroll.");
      return;
    }

    if (isEnrolled) {
      // Already enrolled → go to player
      navigate(`/course-player/${id}`);
      return;
    }

    try {
      const newEnrollment = { userId: currentUser.id, courseId: Number(id) };
      await axios.post("http://localhost:5000/enrollments", newEnrollment);
      setEnrollments([...enrollments, newEnrollment]);
      alert("🎉 Enrolled successfully!");
      // ✅ Redirect directly to CoursePlayer
      navigate(`/course-player/${id}`);
    } catch (err) {
      console.error("Error enrolling:", err);
    }
  };

  if (loading) return <p className="text-center">Loading...</p>;
  if (!course) return <p className="text-center">Course not found</p>;

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Top Section */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h1 className="text-3xl font-bold">{course.title}</h1>
          <p className="mt-2 text-gray-700">{course.description}</p>
          <p className="mt-1 text-sm">
            ⭐ {course.rating} by {course.instructor}
          </p>
        </div>
        <div className="w-72 border p-4 rounded-lg shadow-md">
          <img
            src={course.image}
            alt={course.title}
            className="w-full h-40 object-cover rounded-md mb-3"
          />
          <p className="text-xl font-bold">{course.price}</p>
          <button
            onClick={handleEnroll}
            disabled={isEnrolled}
            className={`w-full mt-3 py-2 rounded-md ${
              isEnrolled
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-600 hover:bg-blue-700 text-white"
            }`}
          >
            {isEnrolled ? "✅ Enrolled" : "🚀 Enroll Now"}
          </button>
        </div>
      </div>

      {/* Course Structure */}
      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2">
          <h2 className="text-xl font-semibold mb-3">Course Content</h2>
          <ul className="space-y-2">
            {course.lectures?.map((lec, index) => (
              <li
                key={index}
                className="flex justify-between items-center bg-gray-100 p-2 rounded-md"
              >
                <span>
                  {lec.title} ({lec.duration})
                </span>
              </li>
            ))}
          </ul>
        </div>
        <div />
      </div>
    </div>
  );
};

export default CourseDetail;

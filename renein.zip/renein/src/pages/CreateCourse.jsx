// src/pages/CreateCourse.jsx
import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useAppContext } from "../context/AppContext";

// 🔑 Extract YouTube ID from link
function extractYouTubeId(url) {
  try {
    const regExp =
      /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  } catch {
    return null;
  }
}

const CreateCourse = () => {
  const navigate = useNavigate();
  const { currentUser } = useAppContext();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");
  const [lectures, setLectures] = useState([]);

  // lecture inputs
  const [lectureTitle, setLectureTitle] = useState("");
  const [lectureDuration, setLectureDuration] = useState("");
  const [lectureLink, setLectureLink] = useState("");

  // add lecture
  const handleAddLecture = () => {
    const videoId = extractYouTubeId(lectureLink);
    if (!videoId) {
      alert("❌ Invalid YouTube link");
      return;
    }

    const newLecture = {
      title: lectureTitle,
      duration: lectureDuration,
      youtubeId: videoId,
    };

    setLectures([...lectures, newLecture]);
    setLectureTitle("");
    setLectureDuration("");
    setLectureLink("");
  };

  // submit course
  const handleSubmit = async (e) => {
    e.preventDefault();

    const newCourse = {
      id: Date.now(),
      title,
      description,
      price: `$${price}`,
      image,
      lectures,
      rating: 0,
      instructor: currentUser ? currentUser.name : "Instructor",
      instructorId: currentUser?.id,
    };

    try {
      await axios.post("http://localhost:5000/courses", newCourse);
      alert("✅ Course created successfully!");
      navigate("/instructor"); // redirect
    } catch (error) {
      console.error("Error creating course:", error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-md rounded-lg mt-6">
      <h2 className="text-2xl font-bold mb-4">Create a New Course</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Title */}
        <div>
          <label className="block text-sm font-medium">Course Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="mt-1 w-full border rounded-md p-2"
            required
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="mt-1 w-full border rounded-md p-2"
            required
          />
        </div>

        {/* Price */}
        <div>
          <label className="block text-sm font-medium">Price ($)</label>
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className="mt-1 w-full border rounded-md p-2"
            required
          />
        </div>

        {/* Image */}
        <div>
          <label className="block text-sm font-medium">Course Image URL</label>
          <input
            type="text"
            value={image}
            onChange={(e) => setImage(e.target.value)}
            className="mt-1 w-full border rounded-md p-2"
            required
          />
        </div>

        {/* Add Lecture */}
        <div className="p-4 border rounded-md bg-gray-50">
          <h3 className="text-lg font-semibold mb-2">Add Lecture</h3>
          <input
            type="text"
            placeholder="Lecture Title"
            value={lectureTitle}
            onChange={(e) => setLectureTitle(e.target.value)}
            className="w-full mb-2 border rounded-md p-2"
          />
          <input
            type="text"
            placeholder="Duration (e.g. 10:30)"
            value={lectureDuration}
            onChange={(e) => setLectureDuration(e.target.value)}
            className="w-full mb-2 border rounded-md p-2"
          />
          <input
            type="text"
            placeholder="YouTube Link"
            value={lectureLink}
            onChange={(e) => setLectureLink(e.target.value)}
            className="w-full mb-2 border rounded-md p-2"
          />
          <button
            type="button"
            onClick={handleAddLecture}
            className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
          >
            ➕ Add Lecture
          </button>

          {/* List of lectures */}
          <ul className="mt-3 list-disc pl-6 text-sm">
            {lectures.map((lec, index) => (
              <li key={index}>
                {lec.title} ({lec.duration}) →{" "}
                <span className="font-mono">{lec.youtubeId}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Submit */}
        <button
          type="submit"
          className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700"
        >
          ✅ Create Course
        </button>
      </form>
    </div>
  );
};

export default CreateCourse;

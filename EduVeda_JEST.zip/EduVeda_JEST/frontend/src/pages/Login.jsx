import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { AppContext } from "../context/AppContext";
 
const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(""); // <-- Add state for server error messages
  const { login } = useContext(AppContext);
  const navigate = useNavigate();
 
  const handleLogin = async (e) => {
    e.preventDefault();
    setError(""); // Clear previous errors
 
    // Basic presence check
    if (!email || !password) {
      setError("Email and password are required");
      return;
    }
 
    // Email format validation
    const studentEmailRegex = /^[^\s@]+@stu\.com$/;
    const instructorEmailRegex = /^[^\s@]+@ins\.com$/;
    const isValidEmail = studentEmailRegex.test(email) || instructorEmailRegex.test(email);
 
    if (!isValidEmail) {
      setError("Invalid credentials");
      return;
    }
 
    // Password validation
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>/?]).{8,}$/;
    if (!passwordRegex.test(password)) {
      // NOTE: This client-side validation logic is confusing. 
      // It checks password complexity but returns an error suggesting the email is wrong.
      // It's safer to only rely on server response or provide a clearer client-side message.
      // For this cleanup, I'll update the error message to be more generic, 
      // preventing information leakage about required password complexity.
      setError("Invalid credentials"); 
      return;
    }
 
    try {
      const res = await axios.post("http://localhost:3000/api/v1/auth/login", {
        username: email,
        password,
      });
 
      if (res.data && res.data.jwt) {
        login(res.data);
 
        // Redirect based on role
        if (res.data.role === "Instructor") navigate("/instructor-dashboard");
        else if (res.data.role === "Admin") navigate("/admin-dashboard");
        else navigate("/learning-dashboard");
      } else {
        // This case might be caught by the server error block below, 
        // but included for safety if the response status is 200 but the body is unexpected.
        setError("Invalid email or password");
      }
    } catch (err) {
      if (err.response) {
        if (err.response.status === 400) setError("Bad request: check your email/password");
        else if (err.response.status === 401) setError("Invalid email or password");
        else setError(`Server error: ${err.response.status}`);
      } else {
        setError("Network error: unable to reach server");
      }
      console.error("Login failed:", err);
    }
  };
 
  return (
    <div className="max-w-md mx-auto mt-10 p-6 border rounded-lg shadow bg-white">
      <h2 className="text-2xl font-bold mb-4">Login</h2>
 
      {error && (
        <div className="mb-4 text-red-600 font-medium">
          {error}
        </div>
      )}
 
      <form onSubmit={handleLogin} className="space-y-4">
        <div>
          <label htmlFor="email" className="block text-sm font-medium">Email</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border p-2 rounded-md"
            required
          />
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border p-2 rounded-md"
            required
          />
        </div>
 
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700"
        >
          Login
        </button>
      </form>
    </div>
  );
};
 
export default Login;
import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
 
const API_BASE = "http://localhost:3000/api/v1";
 
const Signup = () => {
  const [name, setName] = useState("");
  const [role, setRole] = useState("Student"); // default role
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
 
  const handleSignup = async (e) => {
    e.preventDefault();
    setError(""); // Clear previous errors
 
    // Basic presence check
    if (!name || !email || !password || !role) {
      setError("All fields are required");
      return;
    }
 
    // Email format validation based on role
    const studentEmailRegex = /^[^\s@]+@stu\.com$/;
    const instructorEmailRegex = /^[^\s@]+@ins\.com$/;
 
    if (role === "Student" && !studentEmailRegex.test(email)) {
      setError("Student email must end with @stu.com");
      return;
    }
 
    if (role === "Instructor" && !instructorEmailRegex.test(email)) {
      setError("Instructor email must end with @ins.com");
      return;
    }
 
    // Password validation
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>/?]).{8,}$/;
    if (!passwordRegex.test(password)) {
      setError("Password must be at least 8 characters long, include one uppercase letter, one number, and one special character");
      return;
    }
 
    try {
      // check if user already exists
      // NOTE: This client-side check is usually unreliable in a real-world scenario 
      // since the server's POST endpoint should handle the conflict check internally.
      // Assuming this is a mock API setup where a GET check is expected before POST.
      const existingUser = await axios.get(`${API_BASE}/users?email=${email}`);
      
      const userExists = Array.isArray(existingUser.data)
        ? existingUser.data.length > 0
        : existingUser.data.users?.some((u) => u.email === email);
 
      if (userExists) {
        setError("User already exists. Please login.");
        return;
      }
 
      // create new user
      const newUser = {
        name,
        role,
        email,
        password,
        username: email, // for login compatibility
      };
 
      await axios.post(`${API_BASE}/users`, newUser);
      navigate("/login");
    } catch (err) {
      // Handling server-side errors, e.g., if the POST itself fails due to validation/conflict
      // which wasn't caught by the GET check.
      if (err.response && err.response.data && err.response.data.message) {
        setError(err.response.data.message);
      } else {
        setError("Something went wrong. Try again.");
      }
      console.error("Signup failed:", err);
    }
  };
 
  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <form
        onSubmit={handleSignup}
        className="bg-white p-8 rounded-xl shadow-lg w-96"
      >
        <h2 className="text-2xl font-bold mb-6 text-center">Sign Up</h2>
 
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
 
        <input
          type="text"
          placeholder="Full Name"
          className="w-full p-3 border rounded mb-4"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
 
        <select
          className="w-full p-3 border rounded mb-4"
          value={role}
          onChange={(e) => setRole(e.target.value)}
        >
          <option value="Student">Student</option>
          <option value="Instructor">Instructor</option>
        </select>
 
        <input
          type="email"
          placeholder="Email"
          className="w-full p-3 border rounded mb-4"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
 
        <input
          type="password"
          placeholder="Password"
          className="w-full p-3 border rounded mb-4"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
 
        <button
          type="submit"
          className="w-full bg-indigo-600 text-white p-3 rounded hover:bg-indigo-700"
        >
          Sign Up
        </button>
      </form>
    </div>
  );
};
 
export default Signup;
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BrowserRouter } from 'react-router-dom';
import axios from 'axios';
import Login from '../Login';
import { AppContext } from '../../context/AppContext';

// Mock axios
jest.mock('axios');
const mockedAxios = axios;

// Mock react-router-dom
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => {
  const actual = jest.requireActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

// Mock login function
const mockLogin = jest.fn();

const renderLogin = () => {
  return render(
    <AppContext.Provider value={{ login: mockLogin }}>
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    </AppContext.Provider>
  );
};

describe('Login Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    console.error.mockRestore();
  });

  test('renders login form', () => {
    renderLogin();
    expect(screen.getByRole('heading', { name: 'Login' })).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Password')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Login' })).toBeInTheDocument();
  });

  test('updates email and password on input change', async () => {
    const user = userEvent.setup();
    renderLogin();

    const emailInput = screen.getByLabelText('Email');
    const passwordInput = screen.getByLabelText('Password');

    await user.type(emailInput, 'test@stu.com');
    await user.type(passwordInput, 'Password123!');

    expect(emailInput.value).toBe('test@stu.com');
    expect(passwordInput.value).toBe('Password123!');
  });

  test('shows error for missing email and password', async () => {
    renderLogin();

    const form = document.querySelector('form');
    fireEvent.submit(form);

    expect(screen.getByText('Email and password are required')).toBeInTheDocument();
  });

  test('shows error for invalid email format', async () => {
    const user = userEvent.setup();
    renderLogin();

    const emailInput = screen.getByLabelText('Email');
    const passwordInput = screen.getByLabelText('Password');
    const form = document.querySelector('form');

    await user.type(emailInput, 'invalidemail.com');
    await user.type(passwordInput, 'Password123!');
    fireEvent.submit(form);

    expect(screen.getByText('Invalid credentials')).toBeInTheDocument();
  });

  test('shows error for invalid password', async () => {
    const user = userEvent.setup();
    renderLogin();

    const emailInput = screen.getByLabelText('Email');
    const passwordInput = screen.getByLabelText('Password');
    const form = document.querySelector('form');

    await user.type(emailInput, 'test@stu.com');
    await user.type(passwordInput, 'weak');
    fireEvent.submit(form);

    expect(screen.getByText('Invalid credentials')).toBeInTheDocument();
  });

  test('successful login navigates to dashboard', async () => {
    const user = userEvent.setup();
    mockedAxios.post.mockResolvedValueOnce({
      data: { jwt: 'token', role: 'Student' },
    });

    renderLogin();

    const emailInput = screen.getByLabelText('Email');
    const passwordInput = screen.getByLabelText('Password');
    const submitButton = screen.getByRole('button', { name: 'Login' });

    await user.type(emailInput, 'test@stu.com');
    await user.type(passwordInput, 'Password123!');
    await user.click(submitButton);

    await waitFor(() => {
      expect(mockedAxios.post).toHaveBeenCalledWith('http://localhost:3000/api/v1/auth/login', {
        username: 'test@stu.com',
        password: 'Password123!',
      });
      expect(mockLogin).toHaveBeenCalledWith({ jwt: 'token', role: 'Student' });
      expect(mockNavigate).toHaveBeenCalledWith('/learning-dashboard');
    });
  });

  test('login failure shows error', async () => {
    const user = userEvent.setup();
    mockedAxios.post.mockRejectedValueOnce({
      response: { status: 401 },
    });

    renderLogin();

    const emailInput = screen.getByLabelText('Email');
    const passwordInput = screen.getByLabelText('Password');
    const submitButton = screen.getByRole('button', { name: 'Login' });

    await user.type(emailInput, 'test@stu.com');
    await user.type(passwordInput, 'Password123!');
    await user.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('Invalid email or password')).toBeInTheDocument();
    });
  });
});

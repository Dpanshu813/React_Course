import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BrowserRouter } from 'react-router-dom';
import axios from 'axios';
import Signup from '../Signup';

// Mock axios
jest.mock('axios');
const mockedAxios = axios;

// Mock react-router-dom
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => {
  const actual = jest.requireActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

const renderSignup = () => {
  return render(
    <BrowserRouter>
      <Signup />
    </BrowserRouter>
  );
};

describe('Signup Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    console.error.mockRestore();
  });

  test('renders signup form', () => {
    renderSignup();
    expect(screen.getByRole('heading', { name: 'Sign Up' })).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Full Name')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Email')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Password')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Sign Up' })).toBeInTheDocument();
  });

  test('updates form fields on input change', async () => {
    const user = userEvent.setup();
    renderSignup();

    const nameInput = screen.getByPlaceholderText('Full Name');
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');

    await user.type(nameInput, 'John Doe');
    await user.type(emailInput, 'john@stu.com');
    await user.type(passwordInput, 'Password123!');

    expect(nameInput.value).toBe('John Doe');
    expect(emailInput.value).toBe('john@stu.com');
    expect(passwordInput.value).toBe('Password123!');
  });

  test('shows error for missing fields', async () => {
    renderSignup();

    const form = document.querySelector('form');
    fireEvent.submit(form);

    expect(screen.getByText('All fields are required')).toBeInTheDocument();
  });

  test('shows error for invalid student email', async () => {
    const user = userEvent.setup();
    renderSignup();

    const nameInput = screen.getByPlaceholderText('Full Name');
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');
    const submitButton = screen.getByRole('button', { name: 'Sign Up' });

    await user.type(nameInput, 'John Doe');
    await user.type(emailInput, 'john@gmail.com');
    await user.type(passwordInput, 'Password123!');
    await user.click(submitButton);

    expect(screen.getByText('Student email must end with @stu.com')).toBeInTheDocument();
  });

  test('shows error for invalid instructor email', async () => {
    const user = userEvent.setup();
    renderSignup();

    const nameInput = screen.getByPlaceholderText('Full Name');
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');
    const roleSelect = screen.getByRole('combobox');
    const submitButton = screen.getByRole('button', { name: 'Sign Up' });

    await user.selectOptions(roleSelect, 'Instructor');
    await user.type(nameInput, 'Jane Doe');
    await user.type(emailInput, 'jane@gmail.com');
    await user.type(passwordInput, 'Password123!');
    await user.click(submitButton);

    expect(screen.getByText('Instructor email must end with @ins.com')).toBeInTheDocument();
  });

  test('shows error for weak password', async () => {
    const user = userEvent.setup();
    renderSignup();

    const nameInput = screen.getByPlaceholderText('Full Name');
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');
    const submitButton = screen.getByRole('button', { name: 'Sign Up' });

    await user.type(nameInput, 'John Doe');
    await user.type(emailInput, 'john@stu.com');
    await user.type(passwordInput, 'weak');
    await user.click(submitButton);

    expect(screen.getByText('Password must be at least 8 characters long, include one uppercase letter, one number, and one special character')).toBeInTheDocument();
  });

  test('shows error if user already exists', async () => {
    const user = userEvent.setup();
    mockedAxios.get.mockResolvedValueOnce({
      data: [{ email: 'john@stu.com' }],
    });

    renderSignup();

    const nameInput = screen.getByPlaceholderText('Full Name');
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');
    const submitButton = screen.getByRole('button', { name: 'Sign Up' });

    await user.type(nameInput, 'John Doe');
    await user.type(emailInput, 'john@stu.com');
    await user.type(passwordInput, 'Password123!');
    await user.click(submitButton);

    await waitFor(() => {
      expect(mockedAxios.get).toHaveBeenCalledWith('http://localhost:3000/api/v1/users?email=john@stu.com');
      expect(screen.getByText('User already exists. Please login.')).toBeInTheDocument();
    });
  });

  test('successful signup navigates to login', async () => {
    const user = userEvent.setup();
    mockedAxios.get.mockResolvedValueOnce({
      data: [],
    });
    mockedAxios.post.mockResolvedValueOnce({});

    renderSignup();

    const nameInput = screen.getByPlaceholderText('Full Name');
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');
    const submitButton = screen.getByRole('button', { name: 'Sign Up' });

    await user.type(nameInput, 'John Doe');
    await user.type(emailInput, 'john@stu.com');
    await user.type(passwordInput, 'Password123!');
    await user.click(submitButton);

    await waitFor(() => {
      expect(mockedAxios.get).toHaveBeenCalledWith('http://localhost:3000/api/v1/users?email=john@stu.com');
      expect(mockedAxios.post).toHaveBeenCalledWith('http://localhost:3000/api/v1/users', {
        name: 'John Doe',
        role: 'Student',
        email: 'john@stu.com',
        password: 'Password123!',
        username: 'john@stu.com',
      });
      expect(mockNavigate).toHaveBeenCalledWith('/login');
    });
  });

  test('signup failure shows error', async () => {
    const user = userEvent.setup();
    mockedAxios.get.mockResolvedValueOnce({
      data: [],
    });
    mockedAxios.post.mockRejectedValueOnce({
      response: { data: { message: 'Signup failed' } },
    });

    renderSignup();

    const nameInput = screen.getByPlaceholderText('Full Name');
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');
    const submitButton = screen.getByRole('button', { name: 'Sign Up' });

    await user.type(nameInput, 'John Doe');
    await user.type(emailInput, 'john@stu.com');
    await user.type(passwordInput, 'Password123!');
    await user.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('Signup failed')).toBeInTheDocument();
    });
  });
});

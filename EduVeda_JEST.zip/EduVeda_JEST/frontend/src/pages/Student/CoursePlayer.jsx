import React, { useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import YouTube from "react-youtube";
import { AppContext } from "../../context/AppContext";

const API_BASE = "http://localhost:3000/api/v1";

export default function CoursePlayer() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useContext(AppContext);

  const [course, setCourse] = useState(null);
  const [assessments, setAssessments] = useState([]);
  const [playlist, setPlaylist] = useState([]);
  const [activeItem, setActiveItem] = useState(null);
  const [answers, setAnswers] = useState({});
  const [score, setScore] = useState(null);

  useEffect(() => {
    if (!currentUser) navigate("/");
  }, [currentUser, navigate]);

  useEffect(() => {
    if (!courseId) return;

    axios.get(`${API_BASE}/courses/${courseId}`)
      .then(res => setCourse(res.data))
      .catch(err => console.error("Error fetching course:", err));

    axios.get(`${API_BASE}/assessments?courseId=${courseId}`)
      .then(res => setAssessments(res.data.assessments || res.data))
      .catch(err => console.error("Error fetching assessments:", err));
  }, [courseId]);

  useEffect(() => {
    if (!course) return;
    const combined = [...(course.lectures || []), ...(assessments || [])];
    setPlaylist(combined);
    if (combined.length > 0) setActiveItem(combined[0]);
  }, [course, assessments]);

  const isAssessment = (item) => item.questions !== undefined;

  const handleAnswerChange = (qIdx, value) => {
    setAnswers({ ...answers, [qIdx]: value });
  };

  const handleSubmitQuiz = () => {
    const allAnswered = activeItem.questions.every((_, idx) => answers[idx] !== undefined);
    if (!allAnswered) {
      console.log("Please answer all questions before submitting.");
      return;
    }

    let scoreCount = 0;
    activeItem.questions.forEach((q, idx) => {
      if (answers[idx] === q.answer) scoreCount++;
    });
    setScore(`${scoreCount}/${activeItem.questions.length}`);
  };

  if (!course || !playlist) {
    return <p className="text-center mt-10">Loading...</p>;
  }

  return (
    <div className="p-6 max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-1 border rounded-lg p-4 bg-white shadow-sm overflow-y-auto max-h-[80vh]">
        <h2 className="text-lg font-semibold mb-4">📖 Course Playlist</h2>
        <ul className="space-y-2">
          {playlist.map((item) => (
            <li
              key={item.id}
              title={isAssessment(item) ? `Quiz: ${item.title}` : `Lecture: ${item.title}`}
              className={`p-2 rounded cursor-pointer transition duration-200 ease-in-out transform ${
                activeItem?.id === item.id ? "font-medium" : ""
              } hover:border hover:border-black`}
              onClick={() => {
                setActiveItem(item);
                setAnswers({});
                setScore(null);
              }}
            >
              {isAssessment(item) ? `📘 Quiz: ${item.title}` : `▶️ ${item.title}`}
            </li>
          ))}
        </ul>
      </div>

      <div className="md:col-span-2">
        {activeItem ? (
          <div className="bg-white p-4 rounded-lg shadow-sm">
            {isAssessment(activeItem) ? (
              <>
                <h2 className="text-2xl font-bold mb-4">{activeItem.title}</h2>
                {activeItem.questions.map((q, idx) => (
                  <div key={idx} className="mb-4">
                    <p className="font-semibold">{idx + 1}. {q.text}</p>
                    {q.options.map((opt, oIdx) => (
                      <label key={oIdx} className="block">
                        <input
                          type="radio"
                          name={`q${idx}`}
                          value={opt}
                          checked={answers[idx] === opt}
                          onChange={(e) => handleAnswerChange(idx, e.target.value)}
                          className="mr-2"
                        />
                        {opt}
                      </label>
                    ))}
                  </div>
                ))}
                <button
                  onClick={handleSubmitQuiz}
                  className="mt-3 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  Submit Quiz
                </button>
                {score && <p className="mt-4 text-green-600 font-semibold">You scored: {score}</p>}
              </>
            ) : activeItem.youtubeId ? (
              <YouTube videoId={activeItem.youtubeId} opts={{ width: "100%", height: "480" }} />
            ) : (
              <p className="text-red-500">Video not available</p>
            )}
          </div>
        ) : (
          <p className="text-center mt-10">Select a lecture or quiz to play</p>
        )}
      </div>
    </div>
  );
}

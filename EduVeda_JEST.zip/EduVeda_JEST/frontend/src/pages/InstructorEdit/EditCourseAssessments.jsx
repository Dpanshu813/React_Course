// src/pages/EditCourseAssessments.jsx
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const API_BASE = "http://localhost:3000/api/v1";

const EditCourseAssessments = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [assessments, setAssessments] = useState([]);
  const [newAssessmentTitle, setNewAssessmentTitle] = useState("");
  const [newAssessmentDescription, setNewAssessmentDescription] = useState("");
  const [newQuestions, setNewQuestions] = useState([
    { text: "", options: ["", "", ""], answer: "" },
  ]);

  useEffect(() => {
    axios
      .get(`${API_BASE}/assessments?courseId=${id}`)
      .then((res) => setAssessments(res.data))
      .catch((err) => console.error(err));
  }, [id]);

  if (!assessments)
    return <p className="text-center mt-5">Loading assessments...</p>;

  // CRUD handlers (unchanged)
  const handleAssessmentChange = (idx, field, value) => {
    const updated = [...assessments];
    updated[idx][field] = value;
    setAssessments(updated);
  };

  const handleQuestionChange = (assessIdx, qIdx, field, value) => {
    const updated = [...assessments];
    updated[assessIdx].questions[qIdx][field] = value;
    setAssessments(updated);
  };

  const handleOptionChange = (assessIdx, qIdx, optIdx, value) => {
    const updated = [...assessments];
    updated[assessIdx].questions[qIdx].options[optIdx] = value;
    setAssessments(updated);
  };

  const handleAddQuestionToAssessment = (assessIdx) => {
    const updated = [...assessments];
    updated[assessIdx].questions.push({
      text: "",
      options: ["", "", ""],
      answer: "",
    });
    setAssessments(updated);
  };

  const handleDeleteQuestionFromAssessment = (assessIdx, qIdx) => {
    const updated = [...assessments];
    updated[assessIdx].questions.splice(qIdx, 1);
    setAssessments(updated);
  };

  const handleDeleteAssessment = async (assessId) => {
    try {
      await axios.delete(`${API_BASE}/assessments/${assessId}`);
      setAssessments(assessments.filter((a) => a.id !== assessId));
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddNewAssessment = async () => {
    if (!newAssessmentTitle) return console.log("Assessment title required");
    const newAssessment = {
      id: Date.now().toString(),
      courseId: id,
      title: newAssessmentTitle,
      description: newAssessmentDescription,
      questions: newQuestions,
    };
    try {
      await axios.post(`${API_BASE}/assessments`, newAssessment);
      setAssessments([...assessments, newAssessment]);
      setNewAssessmentTitle("");
      setNewAssessmentDescription("");
      setNewQuestions([{ text: "", options: ["", "", ""], answer: "" }]);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveAssessments = async () => {
    try {
      await Promise.all(
        assessments.map((a) => axios.put(`${API_BASE}/assessments/${a.id}`, a))
      );
      navigate("/instructor-dashboard");
    } catch (err) {
      console.error(err);
    }
  };

  // New Assessment Question handlers
  const handleNewQuestionChange = (qIdx, field, value) => {
    const updated = [...newQuestions];
    updated[qIdx][field] = value;
    setNewQuestions(updated);
  };
  const handleNewOptionChange = (qIdx, optIdx, value) => {
    const updated = [...newQuestions];
    updated[qIdx].options[optIdx] = value;
    setNewQuestions(updated);
  };
  const handleAddNewQuestion = () => {
    setNewQuestions([
      ...newQuestions,
      { text: "", options: ["", "", ""], answer: "" },
    ]);
  };

  return (
    <div className="max-w-5xl mx-auto p-8 bg-white shadow-xl rounded-2xl mt-10">
      <h2 className="text-3xl font-extrabold text-gray-800 mb-6">
        ✏️ Edit Assessments
      </h2>

      {/* Existing Assessments */}
      {assessments.map((assess, aIdx) => (
        <div
          key={assess.id}
          className="mb-6 bg-gray-50 rounded-xl shadow-sm p-5 border"
        >
          <div className="flex justify-between items-center mb-3">
            <input
              value={assess.title}
              onChange={(e) =>
                handleAssessmentChange(aIdx, "title", e.target.value)
              }
              className="border p-2 rounded-lg w-2/3 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
            <button
              type="button"
              onClick={() => handleDeleteAssessment(assess.id)}
              className="text-red-600 hover:text-red-800 font-semibold"
            >
              ❌ Delete
            </button>
          </div>
          <textarea
            value={assess.description}
            onChange={(e) =>
              handleAssessmentChange(aIdx, "description", e.target.value)
            }
            className="border p-2 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-400"
          />

          <div className="mt-4 space-y-3">
            {assess.questions.map((q, qIdx) => (
              <div
                key={qIdx}
                className="bg-white p-4 rounded-lg shadow border space-y-2"
              >
                <input
                  placeholder="Question"
                  value={q.text}
                  onChange={(e) =>
                    handleQuestionChange(aIdx, qIdx, "text", e.target.value)
                  }
                  className="w-full border p-2 rounded-lg focus:ring-2 focus:ring-indigo-400"
                />
                {q.options.map((opt, oIdx) => (
                  <input
                    key={oIdx}
                    placeholder={`Option ${oIdx + 1}`}
                    value={opt}
                    onChange={(e) =>
                      handleOptionChange(aIdx, qIdx, oIdx, e.target.value)
                    }
                    className="w-full border p-2 rounded-lg focus:ring-2 focus:ring-indigo-400"
                  />
                ))}
                <input
                  placeholder="Answer"
                  value={q.answer}
                  onChange={(e) =>
                    handleQuestionChange(aIdx, qIdx, "answer", e.target.value)
                  }
                  className="w-full border p-2 rounded-lg focus:ring-2 focus:ring-green-400"
                />
                <button
                  type="button"
                  onClick={() =>
                    handleDeleteQuestionFromAssessment(aIdx, qIdx)
                  }
                  className="text-sm text-red-500 hover:text-red-700 font-semibold"
                >
                  Delete Question
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => handleAddQuestionToAssessment(aIdx)}
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg shadow"
            >
              ➕ Add Question
            </button>
          </div>
        </div>
      ))}

      {/* New Assessment */}
      <div className="border p-6 rounded-xl bg-gray-50 shadow-inner">
        <h3 className="font-bold text-lg text-gray-700 mb-3">
          ➕ Create New Assessment
        </h3>
        <input
          placeholder="Title"
          value={newAssessmentTitle}
          onChange={(e) => setNewAssessmentTitle(e.target.value)}
          className="w-full border p-2 rounded-lg mb-2 focus:ring-2 focus:ring-indigo-400"
        />
        <textarea
          placeholder="Description"
          value={newAssessmentDescription}
          onChange={(e) => setNewAssessmentDescription(e.target.value)}
          className="w-full border p-2 rounded-lg mb-3 focus:ring-2 focus:ring-indigo-400"
        />
        {newQuestions.map((q, qIdx) => (
          <div
            key={qIdx}
            className="bg-white border rounded-lg p-4 mb-2 shadow-sm space-y-2"
          >
            <input
              placeholder="Question"
              value={q.text}
              onChange={(e) =>
                handleNewQuestionChange(qIdx, "text", e.target.value)
              }
              className="w-full border p-2 rounded-lg focus:ring-2 focus:ring-indigo-400"
            />
            {q.options.map((opt, oIdx) => (
              <input
                key={oIdx}
                placeholder={`Option ${oIdx + 1}`}
                value={opt}
                onChange={(e) =>
                  handleNewOptionChange(qIdx, oIdx, e.target.value)
                }
                className="w-full border p-2 rounded-lg focus:ring-2 focus:ring-indigo-400"
              />
            ))}
            <input
              placeholder="Answer"
              value={q.answer}
              onChange={(e) =>
                handleNewQuestionChange(qIdx, "answer", e.target.value)
              }
              className="w-full border p-2 rounded-lg focus:ring-2 focus:ring-green-400"
            />
          </div>
        ))}
        <button
          type="button"
          onClick={handleAddNewQuestion}
          className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg shadow mr-2"
        >
          ➕ Add Question
        </button>
        <button
          type="button"
          onClick={handleAddNewAssessment}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg shadow"
        >
          💾 Save New Assessment
        </button>
      </div>

      {/* Save All */}
      <div className="text-center">
        <button
          type="button"
          onClick={handleSaveAssessments}
          className="mt-6 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl shadow-lg font-semibold"
        >
          ✅ Save All Changes
        </button>
      </div>
    </div>
  );
};

export default EditCourseAssessments;

// src/components/CourseCard.jsx
import React from "react";
import { useNavigate } from "react-router-dom";

export default function CourseCard({ course, isEnrolled }) {
  const navigate = useNavigate();

  return (
    <div
      onClick={() => navigate(`/courses/${course.id}`)}
      className="relative cursor-pointer bg-white border rounded-2xl shadow-md hover:shadow-xl transition transform hover:-translate-y-1 duration-300 overflow-hidden"
    >
      {/* Course Image */}
      <img
        src={course.image}
        alt={course.title}
        className="w-full h-44 object-cover"
      />

      {/* Content */}
      <div className="p-5">
        <h3 className="font-bold text-lg text-gray-800">{course.title}</h3>
        <p className="text-gray-500 text-sm mt-1">{course.instructor}</p>
        <p className="text-gray-800 font-semibold mt-2">{course.price}</p>
      </div>

      {/* Enrolled Badge */}
      {isEnrolled && (
        <div className="absolute bottom-3 right-3">
          <span className="px-3 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-700 shadow-sm">
            Enrolled
          </span>
        </div>
      )}
    </div>
  );
}

import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import LandingPage from "./pages/LandingPage";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import CourseDetail from "./pages/Student/CourseDetail";
import CoursePlayer from "./pages/Student/CoursePlayer";
import LearningDashboard from "./pages/Student/LearningDashboard";
import InstructorDashboard from "./pages/Instructor/InstructorDashboard";
import CreateCourse from "./pages/Instructor/CreateCourse";
import EditCourse from "./pages/InstructorEdit/EditCourse";
import EditCourseVideos from "./pages/InstructorEdit/EditCourseVideos";
import EditCourseAssessments from "./pages/InstructorEdit/EditCourseAssessments";
import Enrollment from "./pages/Student/Enrollment";
import Notifications from "./pages/Notifications";
import SearchPage from "./pages/SearchPage";
import InstructorHome from "./pages/Instructor/InstructorHome";
import Home from "./pages/Home";
import ProtectedRoute from "./components/ProtectedRoute";
import { AppProvider } from "./context/AppContext";
import CreateAssessment from "./pages/Instructor/CreateAssessment";

function App() {
  return (
    <AppProvider>
      <Router>
        <Navbar />
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/courses/:id" element={<CourseDetail />} />
          <Route path="/course-player/:courseId" element={<CoursePlayer />} />
          <Route path="/enroll" element={<Enrollment />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/search" element={<SearchPage />} />

          {/* Protected Student Routes */}
          <Route
            path="/student-home"
            element={
              <ProtectedRoute role="Student">
                <Home />
              </ProtectedRoute>
            }
          />
          <Route
            path="/learning-dashboard"
            element={
              <ProtectedRoute role="Student">
                <LearningDashboard />
              </ProtectedRoute>
            }
          />

          {/* Protected Instructor Routes */}
          <Route
            path="/instructor-home"
            element={
              <ProtectedRoute role="Instructor">
                <InstructorHome />
              </ProtectedRoute>
            }
          />
          <Route
            path="/instructor-dashboard"
            element={
              <ProtectedRoute role="Instructor">
                <InstructorDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/create-course"
            element={
              <ProtectedRoute role="Instructor">
                <CreateCourse />
              </ProtectedRoute>
            }
          />
          <Route
            path="/edit-course/:id"
            element={
              <ProtectedRoute role="Instructor">
                <EditCourse />
              </ProtectedRoute>
            }
          />
          <Route
            path="/edit-course/:id/videos"
            element={
              <ProtectedRoute role="Instructor">
                <EditCourseVideos />
              </ProtectedRoute>
            }
          />
          <Route
            path="/edit-course/:id/assessments"
            element={
              <ProtectedRoute role="Instructor">
                <EditCourseAssessments />
              </ProtectedRoute>
            }
          />
          <Route
            path="/create-assessment"
            element={
              <ProtectedRoute role="Instructor">
                <CreateAssessment />
              </ProtectedRoute>
            }
          />
        </Routes>
      </Router>
    </AppProvider>
  );
}

export default App;

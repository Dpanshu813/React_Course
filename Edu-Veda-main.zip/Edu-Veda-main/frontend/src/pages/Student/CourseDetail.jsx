// src/pages/CourseDetail.jsx
import React, { useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { AppContext } from "../../context/AppContext";

const API_BASE = "http://localhost:3000/api/v1";

export default function CourseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser, enrollments, setEnrollments } = useContext(AppContext);

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);

  // Redirect to landing page if user logs out
  useEffect(() => {
    if (!currentUser) {
      navigate("/");
    }
  }, [currentUser, navigate]);

  useEffect(() => {
    axios
      .get(`${API_BASE}/courses/${id}`)
      .then((res) => {
        setCourse(res.data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (!enrollments || enrollments.length === 0) {
      axios
        .get(`${API_BASE}/enrollments`)
        .then((res) => setEnrollments(res.data))
        .catch(() => {});
    }
  }, [enrollments, setEnrollments]);

  const isEnrolled = enrollments?.some(
    (e) => String(e.userId) === String(currentUser?.id) && String(e.courseId) === String(id)
  );

  const handleEnroll = async () => {
    if (!currentUser) return;
    if (isEnrolled) {
      navigate(`/course-player/${id}`);
      return;
    }
    try {
      const newEnrollment = { userId: currentUser.id, courseId: id };
      const res = await axios.post(`${API_BASE}/enrollments`, newEnrollment);
      setEnrollments([...enrollments, res.data]);
      navigate(`/course-player/${id}`);
    } catch (err) {
      console.error("Error enrolling:", err);
    }
  };

  const handleUnenroll = async () => {
    try {
      const enrollment = enrollments.find(
        (e) => String(e.userId) === String(currentUser?.id) && String(e.courseId) === String(id)
      );
      if (!enrollment) return;

      await axios.delete(`${API_BASE}/enrollments/${enrollment.id}`);
      setEnrollments(enrollments.filter((e) => e.id !== enrollment.id));
    } catch (err) {
      console.error("Error unenrolling:", err);
    }
  };

  if (loading) return <p className="text-center mt-10 text-gray-500">Loading...</p>;
  if (!course) return <p className="text-center mt-10 text-red-500">Course not found</p>;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">{course.title}</h1>
        <p className="text-sm text-gray-500 mb-2">
          ⭐ {course.rating} by {course.instructor}
        </p>
        <p className="text-gray-700">{course.description}</p>
      </div>

      <div className="flex flex-col md:flex-row gap-6 mb-6">
        <div className="flex-1 md:max-w-[65%]">
          <img
            src={course.image}
            alt={course.title}
            className="w-full h-72 md:h-80 object-cover rounded-lg shadow-md"
          />
        </div>

        <div className="w-full md:w-72 border p-6 rounded-xl shadow-md bg-white flex flex-col justify-between md:self-start">
          <p className="text-xl font-semibold mb-4">{course.price}</p>
          {isEnrolled ? (
            <>
              <button
                onClick={() => navigate(`/course-player/${id}`)}
                className="w-full mb-3 py-3 bg-green-600 hover:bg-green-700 text-white rounded-2xl font-medium transition"
              >
                Go to Course Player
              </button>
              <button
                onClick={handleUnenroll}
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-medium transition"
              >
                Unenroll
              </button>
            </>
          ) : (
            <button
              onClick={handleEnroll}
              className="w-full py-3 bg-purple-600 hover:bg-pink-600 text-white rounded-2xl font-medium transition"
            >
              Enroll Now
            </button>
          )}
        </div>
      </div>

      {course.lectures?.length > 0 && (
        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-1 md:max-w-[65%]">
            <h2 className="text-xl font-semibold mb-2">Course Content</h2>
            <ul className="space-y-2">
              {course.lectures.map((lec) => (
                <li
                  key={lec.id}
                  className="flex justify-between items-center bg-gray-100 p-2 rounded"
                >
                  {lec.title} ({lec.duration})
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}

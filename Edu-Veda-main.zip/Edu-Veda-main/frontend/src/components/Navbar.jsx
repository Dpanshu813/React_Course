import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AppContext } from "../context/AppContext";
import logo from "../../owl-logo.webp";

const Navbar = () => {
  const { currentUser, logout } = useContext(AppContext);

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-3 flex justify-between items-center">
        
        {/* Logo + Brand */}
        <Link
          to={
            currentUser?.role === "Instructor"
              ? "/instructor-dashboard"
              : currentUser?.role === "Student"
              ? "/student-home"
              : "/"
          }
          className="flex items-center gap-2 text-xl font-bold text-purple-700 hover:text-purple-800 transition"
        >
          <img
            src={logo}
            alt="EduVeda Logo"
            className="w-10 h-10"
          />
          <span>EduVeda</span>
        </Link>

        {/* Links */}
        <div className="flex items-center gap-6 text-gray-700 font-medium">
          {currentUser?.role === "Student" && (
            <>
              <Link
                to="/student-home"
                className="hover:text-purple-600 transition"
              >
                Home
              </Link>
              <Link
                to="/learning-dashboard"
                className="hover:text-purple-600 transition"
              >
                My Learning
              </Link>
            </>
          )}

          {currentUser ? (
            <>
              <span className="text-gray-600">
                Hi, <span className="font-semibold text-purple-600">{currentUser.name}</span>
              </span>

              {currentUser.role === "Instructor" && (
                <Link
                  to="/instructor-dashboard"
                  className="hover:text-purple-600 transition"
                >
                  Instructor Dashboard
                </Link>
              )}

              <button
                onClick={logout}
                className="px-4 py-2 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white text-sm font-semibold shadow hover:shadow-lg transition"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="px-4 py-2 rounded-full bg-purple-100 text-purple-700 font-semibold text-sm hover:bg-purple-200 transition"
              >
                Login
              </Link>
              <Link
                to="/signup"
                className="px-4 py-2 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white font-semibold text-sm shadow hover:shadow-lg transition"
              >
                Signup
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
